/*********************************************************
 * Copyright (C) 2010 VMware, Inc. All rights reserved.
 *
 * This program is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the
 * Free Software Foundation version 2 and no later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA
 *
 *********************************************************/

/*
 * vmxnet3Plugin.c --
 *
 *	Implements a plugin for vmxnet3 rings.
 */

#ifdef _WIN32
#pragma warning(push)
#pragma pack(push)
#endif
#include "vm_basic_types.h"
#ifdef _WIN32
#pragma pack(pop)
#pragma warning(pop)
#endif

#include "npa_plugin_api.h"

#include "vmxnet3_defs.h"

/*
 * Log & loglevel. Can change at runtime via debugger.
 * Using 'plugin' prefix to avoid conflict with 
 * static variables used in the shell.
 */
static uint32 pluginLogLevel = 0;
static int pluginLogEnabled = 0;


/*
 * Easy shell API calling macros.
 */
#define Shell_AllocSmallBuffer(_state,_handle,_ringOffset)		\
	(_state)->shellApi.allocSmallBuffer((_handle), (_ringOffset))
#define Shell_AllocLargeBuffer(_state,_handle,_ringOffset)		\
	(_state)->shellApi.allocLargeBuffer((_handle), (_ringOffset))
#define Shell_FreeBuffer(_state,_handle,_ringOffset)			\
	(_state)->shellApi.freeBuffer((_handle), (_ringOffset))
#define Shell_CompleteSend(_state,_handle,_numPkt)			\
	(_state)->shellApi.completeSend((_handle), (_numPkt))
#define Shell_IndicateRecv(_state,_handle,_frame)			\
	(_state)->shellApi.indicateRecv((_handle), (_frame))
#define Shell_Log(_state,_loglevel, _n, _fmt, ...)				\
	do {									\
		if (pluginLogEnabled && (_loglevel) <= (int32)pluginLogLevel) {	\
			(_state)->shellApi.log((_n) + 1,			\
					       "%s: " _fmt,			\
					       __FUNCTION__,			\
					       ##__VA_ARGS__);			\
		}								\
	} while (0)


/*
 * Some standard definitions
 */
#ifndef NULL
#define NULL (void *)0
#endif


/*
 * Utility macro to write a register's value (BAR0)
 */
#define VMXNET3_WRITE_REG(_state,_offset,_value)			\
	*(volatile uint32*)((uint8*)(_state)->memioAddr + (_offset)) =	\
		(_value)


/*
 * Utility macro to align a virtual address
 */
#define ALIGN_VA(_ptr, _align) ((void *)(((uintptr_t)(_ptr) + ((_align) - 1)) &\
                                         ~((_align) - 1)))


/*
 * TCP and UDP checksum offset
 */
#define TCP_CSUM_OFFSET		(16)
#define UDP_CSUM_OFFSET		(6)


/*
 * Vmxnet3 TX queue
 */
typedef struct Vmxnet3PluginTxQueue {
	uint32	txProdOffset;	    /* offset of txProd register */
	uint32	ringSize;	    /* size in desc, aligned correctly */

	uint32	hwCmdInsert;	    /* last cmd insert we told hardware */
	uint32	nextCmdInsert;	    /* index of next txd to fill */
	uint32	nextCmdRemove;      /* index of next txd to clean */
	uint32	nextCompleteRemove; /* index of next to complete */
	uint8	genCmd;             /* current value for gen bit on tx ring */
	uint8	genComplete;        /* current value for gen bit on comp ring */

	Vmxnet3_TxDesc     *txCmdVirt;
	Vmxnet3_TxCompDesc *txCompleteVirt;
} Vmxnet3PluginTxQueue;


/*
 * Vmxnet3 RX ring
 */
typedef struct Vmxnet3PluginRxCmdRing {
	uint32 rxProdOffset; /* offset of register */
	uint32 cookieOffset; /* 1st ring = 0, 2nd ring = (size of 1st ring) */
	uint32 ringSize;     /* size in desc, copied from adapter->rxRingLength */

	uint32 nextCmdInsert;
	uint32 nextCmdRemove;

	uint8  genBit;

	Vmxnet3_RxDesc *ring;
} Vmxnet3PluginRxCmdRing;


/*
 * Vmxnet3 RX queue
 */
typedef struct Vmxnet3PluginRxQueue {
	Vmxnet3PluginRxCmdRing cmdRing[2];

	uint32 ringCompleteSize;
	Vmxnet3_RxCompDesc *rxCompleteVirt;

	Shell_RecvFrame frame;

	uint32 nextCompleteRemove;
	uint8  genComplete;
} Vmxnet3PluginRxQueue;

/*
 * Vmxnet3 Plugin state
 */
typedef struct Vmxnet3PluginCustomState {
	Vmxnet3PluginTxQueue txQueues[PLUGIN_MAX_TX_QUEUES];
	Vmxnet3PluginRxQueue rxQueues[PLUGIN_MAX_RX_QUEUES];
	uint32 maxSgLength;
} Vmxnet3PluginCustomState;

#define VMXNET3_PLUGIN_STATE(state)				\
	((Vmxnet3PluginCustomState *)PLUGIN_PRIVATE((state)))


#ifndef ASSERT
#define ASSERT(_x) /* XXX */
#define C_ASSERT(_x) /* XXX */
#endif


/*
 *-----------------------------------------------------------------------------
 *
 * MoveMemory --
 *
 *	Copy the content of a memory region to another (memcpy).
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static INLINE void
MoveMemory(void *dst,
	   void *src,
	   size_t length)
{
	size_t i;
	for (i = 0; i < length; ++i) {
		((uint8 *)dst)[i] = ((uint8 *)src)[i];
	}
}


/*
 *-----------------------------------------------------------------------------
 *
 * ZeroMemory --
 *
 *	Clear a memory region. Equivalent to memset(memory, 0, length).
 *
 * Results:
 *	None.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static INLINE void
ZeroMemory(void *memory,
	   size_t length)
{
	size_t i;
	for (i = 0; i < length; ++i) {
		((uint8 *)memory)[i] = 0;
	}
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_SwInit --
 *
 *	Init any private software state.
 *
 * Results:
 *	0 on success, otherwise 1.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_SwInit(Plugin_State *state)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	uint32 i;

	if (state->majorVersion != 1 || state->size < sizeof (*state)) {
		return 1;
	}

	for (i = 0; i < state->numRxQueues; ++i) {
		Vmxnet3PluginRxQueue *rxQueue = &(customState->rxQueues[i]);
		uint32 j;

		/* check ring size & adjust 2nd ring size */
		rxQueue->cmdRing[0].ringSize = state->rxQueues[i].ringSize;
		if ((state->features & PLUGIN_FEATURES_LRO) ||
		    state->mtu > SHELL_SMALL_RECV_BUFFER_SIZE) {
			rxQueue->cmdRing[1].ringSize =
				state->rxQueues[i].ringSize;
		} else {
			rxQueue->cmdRing[1].ringSize = 32;
		}
		rxQueue->cmdRing[0].cookieOffset = 0;
		rxQueue->cmdRing[1].cookieOffset = rxQueue->cmdRing[0].ringSize;
		ASSERT(rxQueue->cmdRing[0].ringSize != 0);
		ASSERT((rxQueue->cmdRing[0].ringSize &
			VMXNET3_RING_SIZE_MASK) == 0);
		ASSERT(rxQueue->cmdRing[1].ringSize != 0);
		ASSERT((rxQueue->cmdRing[1].ringSize &
			VMXNET3_RING_SIZE_MASK) == 0);

		for (j = 0; j < 2; ++j) {
			Vmxnet3PluginRxCmdRing *cmdRing = rxQueue->cmdRing + j;

			/* initialize command ring management & gen values */
			cmdRing->nextCmdInsert = 0;
			cmdRing->nextCmdRemove = 0;
			cmdRing->genBit = VMXNET3_INIT_GEN;
		}
		/* setup the two command rings */
		rxQueue->cmdRing[0].ring =
			ALIGN_VA(state->rxQueues[i].ringBaseVA,
				 VMXNET3_RING_BA_ALIGN);
		rxQueue->cmdRing[1].ring =
			ALIGN_VA((uint8 *)rxQueue->cmdRing[0].ring +
				 rxQueue->cmdRing[0].ringSize *
				 sizeof (Vmxnet3_RxDesc),
				 VMXNET3_RING_BA_ALIGN);

		/* RX completion ring follows second RX command ring */
		rxQueue->ringCompleteSize = rxQueue->cmdRing[0].ringSize +
			rxQueue->cmdRing[1].ringSize;
		rxQueue->rxCompleteVirt =
			ALIGN_VA((uint8 *)rxQueue->cmdRing[1].ring +
				 rxQueue->cmdRing[1].ringSize *
				 sizeof (Vmxnet3_RxDesc),
				 VMXNET3_RING_BA_ALIGN);

		/* check for overflow */
		if (((uint8 *)rxQueue->rxCompleteVirt) +
		    sizeof (Vmxnet3_RxCompDesc) * rxQueue->ringCompleteSize >
		    state->rxQueues[i].ringBaseVA +
		    state->rxQueues[i].ringLength) {
			Shell_Log(state, 1, 0,
				  "rx shared area size is too small\n");
			return 1;
		}

		/* initialize completion ring management & gen values */
                rxQueue->nextCompleteRemove = 0;
		rxQueue->genComplete = VMXNET3_INIT_GEN;

		rxQueue->cmdRing[0].rxProdOffset = VMXNET3_REG_RXPROD  +
			(VMXNET3_REG_ALIGN * i);
		rxQueue->cmdRing[1].rxProdOffset = VMXNET3_REG_RXPROD2 +
			(VMXNET3_REG_ALIGN * i);

                ZeroMemory(&rxQueue->frame, sizeof (Shell_RecvFrame));

		Shell_Log(state, 1, 8, "rxQueue[%u] %p cmdRing[0] %p %u "
			  "cmdRing[1] %p %u compRing %p %u\n", i, rxQueue,
			  rxQueue->cmdRing[0].ring,
			  rxQueue->cmdRing[0].ringSize,
			  rxQueue->cmdRing[1].ring,
			  rxQueue->cmdRing[1].ringSize,
			  rxQueue->rxCompleteVirt,
			  rxQueue->ringCompleteSize);
	}

	for (i = 0; i < state->numTxQueues; i++) {
		Vmxnet3PluginTxQueue *txQueue = &customState->txQueues[i];

		/* check ring size */
		txQueue->ringSize = state->txQueues[i].ringSize;
		ASSERT(txQueue->ringSize != 0);
		ASSERT((txQueue->ringSize & VMXNET3_RING_SIZE_MASK) == 0);

		txQueue->txCmdVirt = ALIGN_VA(state->txQueues[i].ringBaseVA,
					      VMXNET3_RING_BA_ALIGN);

		/* TX completion ring follows the TX command ring */
		txQueue->txCompleteVirt = ALIGN_VA((uint8 *)txQueue->txCmdVirt +
						   txQueue->ringSize *
						   sizeof (Vmxnet3_TxDesc),
						   VMXNET3_RING_BA_ALIGN);

		/* check for overflow */
		if (((uint8 *)txQueue->txCompleteVirt) +
		    sizeof (Vmxnet3_TxCompDesc) * txQueue->ringSize >
		    state->txQueues[i].ringBaseVA +
		    state->txQueues[i].ringLength) {
			Shell_Log(state, 1, 0,
				  "tx shared area size is too small\n");
			return 1;
		}

		/* initialize ring management & gen values */
		txQueue->hwCmdInsert = 0;
		txQueue->nextCmdInsert = 0;
		txQueue->nextCmdRemove = 0;
		txQueue->nextCompleteRemove = 0;
		txQueue->genCmd = VMXNET3_INIT_GEN;
		txQueue->genComplete = VMXNET3_INIT_GEN;

		txQueue->txProdOffset = VMXNET3_REG_TXPROD +
			(VMXNET3_REG_ALIGN * i);

		Shell_Log(state, 1, 5,
			  "txQueue[%u] %p cmdRing %p %u compRing %p\n",
			  i, txQueue, txQueue->txCmdVirt, txQueue->ringSize,
			  txQueue->txCompleteVirt);
	}

	/* setup max number of SGs per received frame */
	if (state->features & PLUGIN_FEATURES_LRO) {
		customState->maxSgLength = SHELL_MAX_LRO_RECV_SG_LEN;
	} else {
		customState->maxSgLength = SHELL_MAX_RECV_SG_LEN;
	}

	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_ReinitRxRing --
 *
 *	Reset and clear RX ring(s) for the specified queue.
 *
 * Results:
 *      Always 0.
 *
 * Side effects:
 *      None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_ReinitRxRing(Plugin_State *state,
			   uint32 queueNum)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	Vmxnet3PluginRxQueue *rxQueue = &customState->rxQueues[queueNum];
	uint32 i;

	for (i = 0; i < 2; ++i) {
		Vmxnet3PluginRxCmdRing *cmdRing = rxQueue->cmdRing + i;

		/*
		 * Can't ASSERT(nextCmdInsert == nextCmdRemove) since these
		 * aren't updated when we garbage collected the buffers from
		 * the ring.
		 */
#ifdef VMX86_DEBUG
		if (cmdRing->nextCmdInsert != cmdRing->nextCmdRemove) {
			Shell_Log(state, 2, 2, "cmdInsert %u != cmdRemove %u\n",
				  cmdRing->nextCmdInsert,
				  cmdRing->nextCmdRemove);
		}
#endif
		cmdRing->nextCmdInsert = 0;
		cmdRing->nextCmdRemove = 0;
		cmdRing->genBit = VMXNET3_INIT_GEN;

		Shell_Log(state, 1, 3, "cmdRing[%u] %p %u\n", i, cmdRing,
			  cmdRing->ringSize);
		ASSERT(cmdRing->ringSize);
		ASSERT(cmdRing->ring);
		ZeroMemory(cmdRing->ring,
			   sizeof (Vmxnet3_RxDesc) * cmdRing->ringSize);
	}
	ASSERT(rxQueue->rxCompleteVirt);
	ASSERT(rxQueue->ringCompleteSize);
	ZeroMemory(rxQueue->rxCompleteVirt,
		   sizeof (Vmxnet3_RxCompDesc) *
		   rxQueue->ringCompleteSize);
	rxQueue->nextCompleteRemove = 0;
	rxQueue->genComplete = VMXNET3_INIT_GEN;

	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_ReinitTxRing --
 *
 *	Reset and clear TX ring for the specified queue.
 *
 * Results:
 *	Always 0.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_ReinitTxRing(Plugin_State *state,
			   uint32 queueNum)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	Vmxnet3PluginTxQueue *txQueue = &customState->txQueues[queueNum];

	txQueue->hwCmdInsert = 0;
	txQueue->nextCmdInsert = 0;
	txQueue->nextCmdRemove = 0;
	txQueue->nextCompleteRemove = 0;
	txQueue->genCmd = VMXNET3_INIT_GEN;
	txQueue->genComplete = VMXNET3_INIT_GEN;

	ZeroMemory(txQueue->txCmdVirt,
		   sizeof(Vmxnet3_TxDesc) * txQueue->ringSize);
	ZeroMemory(txQueue->txCompleteVirt,
		   sizeof(Vmxnet3_TxCompDesc) * txQueue->ringSize);
	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * ComputeRingIndex --
 *
 *	Adds a offset to a ring index value, taking into account
 *	the potential for wrapping around to the beginning of the rx ring.
 *
 * Results:
 *	Index in the ring.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32
ComputeRingIndex(Vmxnet3PluginRxCmdRing *ring,
		 uint32 base,
		 uint32 offset)
{
	uint32 result = base + offset;

	ASSERT(offset < ring->ringSize);
	if (result >= ring->ringSize) {
		result -= ring->ringSize;
	}
	return result;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_AddBuffersToRxRing --
 *
 *	Attempts to add buffers to RX ring(s).
 *
 * Results:
 *	Always 0.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_AddBuffersToRxRing(Plugin_State *state,
				 uint32 queueNum)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	struct Shell_RxQueueHandle *handle = state->rxQueues[queueNum].handle;
	Vmxnet3PluginRxQueue *rxQueue = &customState->rxQueues[queueNum];
	Vmxnet3PluginRxCmdRing *cmdRing0 = &rxQueue->cmdRing[0];
	Vmxnet3PluginRxCmdRing *cmdRing1 = &rxQueue->cmdRing[1];
	uint32 oldInsert1;
	uint32 oldInsert2;

	oldInsert1 = rxQueue->cmdRing[0].nextCmdInsert;
	oldInsert2 = rxQueue->cmdRing[1].nextCmdInsert;

	if (state->mtu <= SHELL_SMALL_RECV_BUFFER_SIZE) {
		uint32 nextCmd;

		nextCmd = ComputeRingIndex(cmdRing0, cmdRing0->nextCmdInsert, 1);
		Shell_Log(state, 2, 2, "nextCmd %u, nextCmdRemove %u\n",
			  nextCmd, cmdRing0->nextCmdRemove);

		/* fill the ring with 2k skb buffers */
		while (nextCmd != cmdRing0->nextCmdRemove) {
			uint64 buffer;

			Vmxnet3_RxDesc *desc0 = cmdRing0->ring +
				cmdRing0->nextCmdInsert;

			ASSERT(cmdRing0->cookieOffset == 0);
			buffer = Shell_AllocSmallBuffer(state, handle,
							cmdRing0->nextCmdInsert);
			if (buffer == 0) {
				break;
			}

			desc0->addr  = buffer;
			desc0->len   = SHELL_SMALL_RECV_BUFFER_SIZE;
			desc0->btype = VMXNET3_RXD_BTYPE_HEAD;
			desc0->dtype = 0;
			desc0->rsvd  = 0;
			desc0->ext1  = 0;
			desc0->gen = cmdRing0->genBit;

			Shell_Log(state, 2, 4, "desc0[%u] addr:%lu len:%u "
				  "gen:%u\n", cmdRing0->nextCmdInsert,
				  desc0->addr, desc0->len, desc0->gen);

			cmdRing0->nextCmdInsert = nextCmd;
			if (cmdRing0->nextCmdInsert == 0) { /* we've wrapped */
				VMXNET3_FLIP_RING_GEN(cmdRing0->genBit);
			}
			nextCmd = ComputeRingIndex(cmdRing0,
						   cmdRing0->nextCmdInsert, 1);
		}

		/*
		 * We're not using the large buffer queue or the
		 * second ring unless LPD is enabled
		 */
		ASSERT((state->features & PLUGIN_FEATURES_LRO) ||
		       cmdRing1->nextCmdInsert == 0);
		ASSERT((state->features & PLUGIN_FEATURES_LRO) ||
		       cmdRing1->nextCmdRemove == 0);
	} else {
		/*
		 * When jumbo frames are used, nextCmdRemove might
		 * point to the 2k buffer or either of the 4k buffers,
		 * depending on whether one or both of the 4k buffers
		 * were needed to receive a frame.  So, this loop
		 * needs to check for +1, +2, and +3 when it comes to
		 * buffer occupancy.  The alternative is to have the
		 * code that walks the completion ring detect when the
		 * 4k buffer(s) weren't used and skip it, but offhand
		 * I think that approach would be more overhead
		 * compared to having an additional check in this
		 * function (simpler, and this function ideally won't
		 * run as often).
		 */

		Shell_Log(state, 2, 3, "nextCmd %u-%u, nextCmdRemove %u\n",
			 ComputeRingIndex(cmdRing0, cmdRing0->nextCmdInsert, 1),
			 ComputeRingIndex(cmdRing0, cmdRing0->nextCmdInsert, 3),
			 cmdRing0->nextCmdRemove);

		while (ComputeRingIndex(cmdRing0, cmdRing0->nextCmdInsert, 1) !=
		       cmdRing0->nextCmdRemove &&
		       ComputeRingIndex(cmdRing0, cmdRing0->nextCmdInsert, 2) !=
		       cmdRing0->nextCmdRemove &&
		       ComputeRingIndex(cmdRing0, cmdRing0->nextCmdInsert, 3) !=
		       cmdRing0->nextCmdRemove) {
			Vmxnet3_RxDesc *desc[3];
			uint32 bufferOffset[3];
			uint8  genBit[3];
			uint64 bufferPA[3];

			genBit[0] = cmdRing0->genBit;
			genBit[1] = cmdRing0->genBit;
			genBit[2] = cmdRing0->genBit;

			ASSERT(cmdRing0->cookieOffset == 0);
			/*
			 * Compute next ring entries and gen values
			 * for these entries
			 */
			bufferOffset[0] = cmdRing0->nextCmdInsert;
			bufferOffset[1] = bufferOffset[0] + 1;
			if (bufferOffset[1] >= cmdRing0->ringSize) {
				bufferOffset[1] = 0;
				bufferOffset[2] = 1;
				VMXNET3_FLIP_RING_GEN(genBit[1]);
				VMXNET3_FLIP_RING_GEN(genBit[2]);
			} else {
				bufferOffset[2] = bufferOffset[1] + 1;
				if (bufferOffset[2] >= cmdRing0->ringSize) {
					bufferOffset[2] = 0;
					VMXNET3_FLIP_RING_GEN(genBit[2]);
				}
			}

			desc[0] = cmdRing0->ring + bufferOffset[0];
			desc[1] = cmdRing0->ring + bufferOffset[1];
			desc[2] = cmdRing0->ring + bufferOffset[2];

			/* allocate 2k + 4k + 4k buffers */
			bufferPA[0] = Shell_AllocSmallBuffer(state, handle,
							     bufferOffset[0]);
			if (!bufferPA[0]) {
				break;
			}

			bufferPA[1] = Shell_AllocLargeBuffer(state, handle,
							     bufferOffset[1]);
			if (!bufferPA[1]) {
				Shell_FreeBuffer(state, handle, bufferOffset[0]);
				break;
			}

			bufferPA[2] = Shell_AllocLargeBuffer(state, handle,
							     bufferOffset[2]);
			if (!bufferPA[2]) {
				Shell_FreeBuffer(state, handle, bufferOffset[0]);
				Shell_FreeBuffer(state, handle, bufferOffset[1]);
				break;
			}

			/* setup the descriptors */
			desc[0]->addr  = bufferPA[0];
			desc[0]->len   = SHELL_SMALL_RECV_BUFFER_SIZE;
			desc[0]->btype = VMXNET3_RXD_BTYPE_HEAD;
			desc[0]->dtype = 0;
			desc[0]->rsvd  = 0;
			desc[0]->ext1  = 0;

			desc[1]->addr  = bufferPA[1];
			desc[1]->len   = SHELL_LARGE_RECV_BUFFER_SIZE;
			desc[1]->btype = VMXNET3_RXD_BTYPE_BODY;
			desc[1]->dtype = 0;
			desc[1]->rsvd  = 0;
			desc[1]->ext1  = 0;

			desc[2]->addr  = bufferPA[2];
			desc[2]->len   = SHELL_LARGE_RECV_BUFFER_SIZE;
			desc[2]->btype = VMXNET3_RXD_BTYPE_BODY;
			desc[2]->dtype = 0;
			desc[2]->rsvd  = 0;
			desc[2]->ext1  = 0;

			desc[2]->gen = genBit[2];
			desc[1]->gen = genBit[1];
			desc[0]->gen = genBit[0];

#ifdef VMX86_DEBUG
			{
				int i;
				for (i = 0; i < 3; i++) {
					Shell_Log(state, 2, 5, "desc%d[%u] "
						  "addr:%lu len:%u gen:%u\n",
						  i,
						  (cmdRing0->nextCmdInsert + i) %
						  cmdRing0->ringSize,
						  desc[i]->addr, desc[i]->len,
						  desc[i]->gen);
				}
			}
#endif

			cmdRing0->nextCmdInsert += 3;
			if (cmdRing0->nextCmdInsert >= cmdRing0->ringSize) {
				cmdRing0->nextCmdInsert -= cmdRing0->ringSize;
				VMXNET3_FLIP_RING_GEN(cmdRing0->genBit);
			}
		}
	}

	if ((state->features & PLUGIN_FEATURES_LRO) ||
	    state->mtu > SHELL_SMALL_RECV_BUFFER_SIZE) {

		Shell_Log(state, 2, 2, "nextCmd %u, nextCmdRemove %u\n",
			  ComputeRingIndex(cmdRing1, cmdRing1->nextCmdInsert, 1),
			  cmdRing1->nextCmdRemove);

		/* fill the 2nd ring with 4k buffers */
		while (ComputeRingIndex(cmdRing1, cmdRing1->nextCmdInsert, 1) !=
		       cmdRing1->nextCmdRemove) {
			uint64 bufferPA;

			Vmxnet3_RxDesc *desc = cmdRing1->ring +
				cmdRing1->nextCmdInsert;

			bufferPA = Shell_AllocLargeBuffer(state, handle,
							cmdRing1->cookieOffset +
							cmdRing1->nextCmdInsert);
			if (!bufferPA) {
				break;
			}

			desc->addr  = bufferPA;
			desc->len   = SHELL_LARGE_RECV_BUFFER_SIZE;
			desc->btype = VMXNET3_RXD_BTYPE_BODY;
			desc->dtype = 0;
			desc->rsvd  = 0;
			desc->ext1  = 0;

			desc->gen = cmdRing1->genBit;

			Shell_Log(state, 2, 4, "desc[%u] addr:%lu len:%u"
				  " gen:%u\n", cmdRing1->nextCmdInsert,
				  desc->addr, desc->len, desc->gen);

			++cmdRing1->nextCmdInsert;
			if (cmdRing1->nextCmdInsert >= cmdRing1->ringSize) {
				cmdRing1->nextCmdInsert = 0;
				VMXNET3_FLIP_RING_GEN(cmdRing1->genBit);
			}
		}
	}

	/*
	 * XXX: what to do for state->updateRxProd?  It is not a
	 * problem for Vmxnet3 backend, but we need to fix this for
	 * Palo devices (UPT).
	 */
	if (state->updateRxProd) {
		if (oldInsert1 != rxQueue->cmdRing[0].nextCmdInsert) {
			VMXNET3_WRITE_REG(state,
					  rxQueue->cmdRing[0].rxProdOffset,
					  rxQueue->cmdRing[0].nextCmdInsert);
		}

		if (oldInsert2 != rxQueue->cmdRing[1].nextCmdInsert) {
			VMXNET3_WRITE_REG(state,
					  rxQueue->cmdRing[1].rxProdOffset,
					  rxQueue->cmdRing[1].nextCmdInsert);
		}
	}
	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_CheckRxRing --
 *
 *	Checks rx ring(s) for received frames.
 *
 * Results:
 *	Non-zero if we need to feed the ring with buffers.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_CheckRxRing(Plugin_State *state,
                          uint32 queueNum,
                          uint32 maxPackets)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	struct Shell_RxQueueHandle *handle = state->rxQueues[queueNum].handle;
	Vmxnet3PluginRxQueue *rxQueue = &customState->rxQueues[queueNum];
	Shell_RecvFrame *frame = &rxQueue->frame;
	uint8 rxBufferWasCompleted = FALSE;
	uint32 packetsFound = 0;

	ZeroMemory(frame, sizeof *frame);

	Shell_Log(state, 1, 3, "desc[%u].gen %u q.gen %u\n",
		  rxQueue->nextCompleteRemove,
		  rxQueue->rxCompleteVirt[rxQueue->nextCompleteRemove].gen,
		  rxQueue->genComplete);
	/* while we have descriptors to process */
	while (rxQueue->rxCompleteVirt[rxQueue->nextCompleteRemove].gen ==
	       rxQueue->genComplete && packetsFound < maxPackets) {
		Vmxnet3_RxCompDesc *currDesc;
		uint32 index;
		uint32 queueID;
		uint8 firstRing; /* first ring vs. second ring */
		Vmxnet3PluginRxCmdRing *cmdRing;
		uint8 discardStoredMDLs = FALSE;
		uint8 discardCurrentDesc = FALSE;
		uint32 currDescCookie;

		/*
		 * XXX not accurate but better than nothing We could
		 * implement a threshold and this function would
		 * return 1 only if the number of desc available is
		 * too small.
		 */
		rxBufferWasCompleted = TRUE;

		currDesc = rxQueue->rxCompleteVirt +
			rxQueue->nextCompleteRemove;
		index = currDesc->rxdIdx;
		queueID = currDesc->rqID;
		Shell_Log(state, 1, 2, "got queue %u index %u\n", queueID,
			  index);
		ASSERT(queueID == queueNum ||
		       queueID == queueNum + state->numRxQueues);
		firstRing = (queueID < state->numRxQueues) ? TRUE : FALSE;

		cmdRing = rxQueue->cmdRing + (firstRing ? 0 : 1);
		currDescCookie = cmdRing->cookieOffset + index;

		/* reclaim any buffers that were skipped by device */
		while (cmdRing->nextCmdRemove != index) {

			Shell_FreeBuffer(state, handle, cmdRing->cookieOffset +
					 cmdRing->nextCmdRemove);

			cmdRing->nextCmdRemove =
				ComputeRingIndex(cmdRing,
						 cmdRing->nextCmdRemove, 1);
		}
		/*
		 * If we got an SOP but have buffers from prior descriptors,
		 * then free them
		 */
		if (currDesc->sop && frame->sgLength > 0) {
			discardStoredMDLs = TRUE;
		}

		/*
		 * if we got non-sop, but we don't have prior MDLs, then skip
		 * this descriptor
		 */
		if (!currDesc->sop && frame->sgLength == 0) {
			discardCurrentDesc = TRUE;
		}

		/*
		 * if ran out of room to store frame, then discard prior and
		 * current desc
		 */
		if (frame->sgLength >= customState->maxSgLength) {
			state->shellApi.log(2, "sgLength exceeded: %u %u\n",
				  frame->sgLength, customState->maxSgLength);
			Shell_Log(state, 1, 2, "sgLength exceeded: %u %u\n",
				  frame->sgLength, customState->maxSgLength);
			discardStoredMDLs = TRUE;
			discardCurrentDesc = TRUE;
		}

		/* Make sure that err isn't set on non-eop frame */
		ASSERT(currDesc->eop || !currDesc->err);

		if (currDesc->eop && currDesc->err) {
			state->shellApi.log(1, "Got error on EOP descriptor: "
				  "fcs %u\n", currDesc->fcs);
			Shell_Log(state, 1, 1, "Got error on EOP descriptor: "
				  "fcs %u\n", currDesc->fcs);
			discardStoredMDLs = TRUE;
			discardCurrentDesc = TRUE;
		}

		/*
		 * if no length, then don't need to bother to add descriptor
		 * to frame
		 */
		if (currDesc->len == 0) {
			discardCurrentDesc = TRUE;
		}

		if (discardStoredMDLs) {
			uint32 i;
			state->shellApi.log(0, "Discarding stored MDLs\n");
			Shell_Log(state, 1, 0, "Discarding stored MDLs\n");
			for (i = 0; i < frame->sgLength; ++i) {
				Shell_FreeBuffer(state, handle,
						 frame->sg[i].ringOffset);
			}
			frame->sgLength = 0;
			frame->byteLength = 0;
		}

		if (discardCurrentDesc) {
			Shell_FreeBuffer(state, handle, currDescCookie);
			goto nextEntry;
		}

		ASSERT(frame->sgLength < customState->maxSgLength);

		/* add MDL to list and set/increment the length */
		ASSERT(currDesc->len > 0);
		frame->sg[frame->sgLength].ringOffset = currDescCookie;
		frame->sg[frame->sgLength].length = currDesc->len;
		frame->byteLength += currDesc->len;
		++frame->sgLength;

		if (currDesc->eop) {
			if (currDesc->ts) {
				frame->vlan = TRUE;
				frame->vlanTag = (uint16)currDesc->tci;

				/* XXX filter on broken hardware(?) */
			} else {
				frame->vlan = FALSE;
				frame->vlanTag = 0;

				/* XXX filter on broken hardware(?) */
			}

			if (currDesc->rssType != VMXNET3_RCD_RSS_TYPE_NONE) {

				frame->rssHashFunction =
					SHELL_RECV_HASH_FUNCTION_TOEPLITZ;
				frame->rssHashValue = currDesc->rssHash;

				switch (currDesc->rssType) {
					case VMXNET3_RCD_RSS_TYPE_IPV4:
						frame->rssHashType = SHELL_RECV_HASH_TYPE_IPV4;
						break;
					case VMXNET3_RCD_RSS_TYPE_TCPIPV4:
						frame->rssHashType = SHELL_RECV_HASH_TYPE_TCPIPV4;
						break;
					case VMXNET3_RCD_RSS_TYPE_IPV6:
						frame->rssHashType = SHELL_RECV_HASH_TYPE_IPV6;
						break;
					case VMXNET3_RCD_RSS_TYPE_TCPIPV6:
						frame->rssHashType = SHELL_RECV_HASH_TYPE_TCPIPV6;
						break;
					default:
						ASSERT(0);
						frame->rssHashType = SHELL_RECV_HASH_TYPE_NONE;
						break;
				}
			} else {
				frame->rssHashFunction =
					SHELL_RECV_HASH_FUNCTION_NONE;
				frame->rssHashValue = 0;
				frame->rssHashType = SHELL_RECV_HASH_TYPE_NONE;
			}

			/*
			 * check on V4 vs V6.  Validity of bits is not based
			 * on CNC.
			 */
			if (currDesc->v4) {
				frame->ipv4 = TRUE;
				frame->ipv6 = FALSE;
				frame->nonIp = FALSE;
			} else if (currDesc->v6) {
				frame->ipv4 = FALSE;
				frame->ipv6 = TRUE;
				frame->nonIp = FALSE;
			} else {
				frame->ipv4 = FALSE;
				frame->ipv6 = FALSE;
				frame->nonIp = TRUE;
			}

			/*
			 * check on TCP vs UDP.  Validity of bits is not based
			 * on CNC, but on v4 or v6.
			 */
			if (currDesc->v4 || currDesc->v6) {
				if (currDesc->tcp) {
					frame->tcp = TRUE;
					frame->udp = FALSE;
				} else if (currDesc->udp) {
					frame->tcp = FALSE;
					frame->udp = TRUE;
				} else {
					frame->tcp = FALSE;
					frame->udp = FALSE;
				}
			} else {
				frame->tcp = FALSE;
				frame->udp = FALSE;
			}

			/* if checksum calculated */
			if (!currDesc->cnc) {
				/* ignore csum and frg */
				if (currDesc->v4) {
					if (currDesc->ipc) {
						frame->ipXsum =
							SHELL_XSUM_CORRECT;
					} else {
						frame->ipXsum =
							SHELL_XSUM_INCORRECT;
					}
				} else {
					frame->ipXsum = SHELL_XSUM_UNKNOWN;
				}

				if (!currDesc->frg &&
				    (currDesc->v4 || currDesc->v6)) {
					if (currDesc->tcp) {
						if (currDesc->tuc) {
							frame->tcpXsum =
							   SHELL_XSUM_CORRECT;
						} else {
							frame->tcpXsum =
							   SHELL_XSUM_INCORRECT;
						}
						frame->udpXsum =
							SHELL_XSUM_UNKNOWN;
					} else if (currDesc->udp) {
						if (currDesc->tuc) {
							frame->udpXsum =
							   SHELL_XSUM_CORRECT;
						} else {
							frame->udpXsum =
							   SHELL_XSUM_INCORRECT;
						}
						frame->tcpXsum =
							SHELL_XSUM_UNKNOWN;
					} else {
						frame->tcpXsum =
							SHELL_XSUM_UNKNOWN;
						frame->udpXsum =
							SHELL_XSUM_UNKNOWN;
					}
				} else { /* ipv4 or ipv6 */
					frame->tcpXsum = SHELL_XSUM_UNKNOWN;
					frame->udpXsum = SHELL_XSUM_UNKNOWN;
				}
			} else { /* cnc */
				frame->tcpXsum = SHELL_XSUM_UNKNOWN;
				frame->udpXsum = SHELL_XSUM_UNKNOWN;
				frame->ipXsum = SHELL_XSUM_UNKNOWN;
			}

			++packetsFound;
			if (Shell_IndicateRecv(state, handle, frame) != 0) {
				/*
				 * for now free buffers, since would
				 * need to handle case where the EOP
				 * descriptor is processed again the
				 * next time this poll function is
				 * called.
				 */
				uint32 i;
				for (i = 0; i < frame->sgLength; ++i) {
					Shell_FreeBuffer(state, handle,
							frame->sg[i].ringOffset);
				}
				/* breaks the loop cleanly */
				packetsFound = maxPackets;
			}
			frame->sgLength = 0;
			frame->byteLength = 0;
		}

	nextEntry:

		/* we processed this command descriptor, so move to the next */
		ASSERT(index == cmdRing->nextCmdRemove);
		cmdRing->nextCmdRemove = ComputeRingIndex(cmdRing,
						     cmdRing->nextCmdRemove, 1);

		/* we processed this completion desc, so move to the next */
		if (++rxQueue->nextCompleteRemove >= rxQueue->ringCompleteSize) {
			rxQueue->nextCompleteRemove = 0;
			VMXNET3_FLIP_RING_GEN(rxQueue->genComplete);
		}
	}

	return rxBufferWasCompleted == TRUE ? 1 : 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_CheckTxRing --
 *
 *	Check tx ring for completed transmits.
 *
 * Results:
 *	Always 0.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_CheckTxRing(Plugin_State *state,
			  uint32 queueNum)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	struct Shell_TxQueueHandle *handle = state->txQueues[queueNum].handle;
	Vmxnet3PluginTxQueue *txQueue = &customState->txQueues[queueNum];
	uint32 numCompleted = 0;
	uint32 index;
	uint32 nextRemove;

	while (txQueue->txCompleteVirt[txQueue->nextCompleteRemove].gen ==
	       txQueue->genComplete) {
		ASSERT(txQueue->txCompleteVirt[txQueue->nextCompleteRemove].rsvd == 0);
		ASSERT(txQueue->txCompleteVirt[txQueue->nextCompleteRemove].type == 0);

		index = txQueue->txCompleteVirt[txQueue->nextCompleteRemove].txdIdx;
		ASSERT(txQueue->txCmdVirt[index].eop);

		++numCompleted;

		nextRemove = index + 1;
		if (nextRemove >= txQueue->ringSize) {
			nextRemove = 0;
		}
		txQueue->nextCmdRemove = nextRemove;

		txQueue->nextCompleteRemove++;
		if (txQueue->nextCompleteRemove >= txQueue->ringSize) {
			txQueue->nextCompleteRemove = 0;
			VMXNET3_FLIP_RING_GEN(txQueue->genComplete);
		}
	}

	if (numCompleted > 0) {
		Shell_Log(state, 1, 1, "numCompleted: %u\n", numCompleted);
		Shell_CompleteSend(state, handle, numCompleted);
	}

	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_AddFrameToTxRing --
 *
 *	Attempts to add frame to transmit ring.
 *
 * Results:
 *	0 if successful, otherwise 1.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_AddFrameToTxRing(Plugin_State *state,
			       uint32 queueNum,
			       const Plugin_SendInfo *info,
			       const Plugin_SgList *frame,
			       Bool lastFrame)
{
	Vmxnet3PluginCustomState *customState = VMXNET3_PLUGIN_STATE(state);
	Vmxnet3PluginTxQueue *txQueue = &customState->txQueues[queueNum];
	uint32 bytesRemainInFrame = frame->totalLength;
	Vmxnet3_TxDesc descTemplate = {0};
	/* can't update nextCmdInsert until success */
	uint32 insertOffset = txQueue->nextCmdInsert;
	/* firstDesc[GenBit] used to set the gen bit as the last operation */
	Vmxnet3_TxDesc *firstDesc = txQueue->txCmdVirt + insertOffset;
	uint8 firstDescGenBit = txQueue->genCmd;
	const Plugin_SgElement *currSg = frame->elements;
	uint32 currSgOffset = 0;
	/* can't update genCmd until success */
	uint8 currentGen = txQueue->genCmd;

	/* set up a template descriptor used for all entries for the frame */
	descTemplate.gen = !currentGen; /* start with "wrong" generation */
	if (info->vlan) {
		descTemplate.ti = 1;
		descTemplate.tci = info->vlanTag;
	}

	if (info->tso) {
		descTemplate.msscof = info->tsoMss;
		descTemplate.om = VMXNET3_OM_TSO;
		/* end of tcp header */
		descTemplate.hlen = (uint16)info->l4DataOffset;
	} else if (info->xsumTcpOrUdp) {
		descTemplate.msscof = info->l4HeaderOffset + (info->tcp ?
							      TCP_CSUM_OFFSET :
							      UDP_CSUM_OFFSET);
		descTemplate.om = VMXNET3_OM_CSUM;
		/* end of ip header */
		descTemplate.hlen = (uint16)info->l4HeaderOffset;
	}

	/* loop to stick buffers in the ring */
	while (bytesRemainInFrame) {
		Vmxnet3_TxDesc *currDesc = txQueue->txCmdVirt + insertOffset;
		uint32 nextOffset;
		uint32 bytesInSg;

		/* make sure we always leave at least one empty
		   descriptor when the ring get full */
		nextOffset = insertOffset + 1;
		if (nextOffset >= txQueue->ringSize) {
			nextOffset = 0;
		}
		if (nextOffset == txQueue->nextCmdRemove) {
			Shell_Log(state, 4, 2,
				  "full ring since nextOffset %u == "
				  "txQueue->nextCmdRemove %u\n",
				  nextOffset, txQueue->nextCmdRemove);
			break;
		}

		/* copy the template and patch in the address/length info */
		MoveMemory(currDesc, &descTemplate, sizeof descTemplate);

		currDesc->addr = currSg->pa + currSgOffset;
		bytesInSg = currSg->length - currSgOffset;

		if (bytesInSg < VMXNET3_MAX_TX_BUF_SIZE) {
			currDesc->len = bytesInSg;
			++currSg;
			currSgOffset = 0;
		} else {
			currDesc->len = 0;
			if (bytesInSg == VMXNET3_MAX_TX_BUF_SIZE) {
				++currSg;
				currSgOffset = 0;
			} else {
				/* don't advance to next SG element */
				currSgOffset += VMXNET3_MAX_TX_BUF_SIZE;
			}
			bytesRemainInFrame -= VMXNET3_MAX_TX_BUF_SIZE;
		}

		bytesRemainInFrame -= currDesc->len;

		/* set EOP/CQ in the last descriptor */
		if (bytesRemainInFrame == 0) {
			currDesc->eop = 1;
			currDesc->cq = 1;
		}

		/* write gen in all descriptors but the first one */
		if (currDesc != firstDesc) {
			currDesc->gen = currentGen;
		}

		Shell_Log(state, 4, 4,
			  "txdesc[%u] sgOffset: %u len: %u gen: %u\n",
			  insertOffset, currSgOffset,
			  currDesc->len, currDesc->gen);

		/* advance to the next desc */
		++insertOffset;
		if (insertOffset >= txQueue->ringSize) {
			insertOffset = 0;
			/* update with new "wrong" generation */
			descTemplate.gen = currentGen;
			VMXNET3_FLIP_RING_GEN(currentGen);
		}
	}

	/* if frame successfully added, then update locations */
	if (bytesRemainInFrame == 0) {
		/* set the correct gen bit of the first descriptor */
		firstDesc->gen = firstDescGenBit;

		/* update state stored in tx queue */
		txQueue->nextCmdInsert = insertOffset;
		txQueue->genCmd = currentGen;
	}

	/*
	 * Update the device register when we're told it's the
	 * last frame.  The assumption/expectation is that for
	 * non-vmxnet3 plugs 'lastFrame' will really be based
	 * on the last frame, whereas for the vmxnet3 plugin the
	 * shell will use the usual vmxnet3 logic/interaction
	 * with the shared memory and use 'lastFrame' to tell
	 * us if we should touch the device register.
	 * It might be more strightforward for the shell to
	 * just touch it for for plugin.
	 *
	 * Also update the register when we run out of
	 * descriptor. This may force the device to process packets.
	 */

	if ((lastFrame || bytesRemainInFrame != 0) &&
	    txQueue->hwCmdInsert != txQueue->nextCmdInsert) {
		VMXNET3_WRITE_REG(state, txQueue->txProdOffset,
				  txQueue->nextCmdInsert);
		txQueue->hwCmdInsert = txQueue->nextCmdInsert;
	}

	return (bytesRemainInFrame == 0) ? 0 : 1;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_EnableInterrupt --
 *
 *	Enables interrupt.
 *
 * Results:
 *	Always 0.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_EnableInterrupt(Plugin_State *state,
			      uint32 messageIndex)
{
	VMXNET3_WRITE_REG(state, VMXNET3_REG_IMR + messageIndex * 8, 0);
	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * Vmxnet3Plugin_DisableInterrupt --
 *
 *	Disables interrupt
 *
 * Results:
 *	Always 0.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

static uint32 PLUGIN_ABI
Vmxnet3Plugin_DisableInterrupt(Plugin_State *state,
			       uint32 messageIndex)
{
	VMXNET3_WRITE_REG(state, VMXNET3_REG_IMR + messageIndex * 8, 1);
	return 0;
}


/*
 *-----------------------------------------------------------------------------
 *
 * NPA_PluginMain --
 *
 *	Return the plugin API to the shell
 *
 * Results:
 *	0 to indicate success.
 *
 * Side effects:
 *	None.
 *
 *-----------------------------------------------------------------------------
 */

uint32
NPA_PluginMain(struct Plugin_Api *pluginApi)
{
	pluginApi->swInit = Vmxnet3Plugin_SwInit;
	pluginApi->reinitRxRing = Vmxnet3Plugin_ReinitRxRing;
	pluginApi->reinitTxRing = Vmxnet3Plugin_ReinitTxRing;
	pluginApi->addBuffersToRxRing = Vmxnet3Plugin_AddBuffersToRxRing;
	pluginApi->addFrameToTxRing = Vmxnet3Plugin_AddFrameToTxRing;
	pluginApi->checkRxRing = Vmxnet3Plugin_CheckRxRing;
	pluginApi->checkTxRing = Vmxnet3Plugin_CheckTxRing;
	pluginApi->enableInterrupt = Vmxnet3Plugin_EnableInterrupt;
	pluginApi->disableInterrupt = Vmxnet3Plugin_DisableInterrupt;
	return 0;
}
