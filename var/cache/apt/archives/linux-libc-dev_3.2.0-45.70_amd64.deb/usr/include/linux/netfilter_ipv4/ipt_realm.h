#ifndef _IPT_REALM_H
#define _IPT_REALM_H

#include <linux/netfilter/xt_realm.h>
#define ipt_realm_info xt_realm_info

#endif /* _IPT_REALM_H */
