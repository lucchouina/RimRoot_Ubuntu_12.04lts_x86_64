class CTSvars:
    CTS_home="/usr/share/pacemaker/tests/cts"
    CRM_CONFIG_DIR="/var/lib/heartbeat/crm"
    CRM_DAEMON_USER="hacluster"
    CRM_DAEMON_DIR="/usr/lib/heartbeat"
    HA_VARLIBHBDIR="/var/lib/heartbeat"
    OCF_ROOT_DIR="/usr/lib/ocf"
    INITDIR="/etc/init.d"
